import React from 'react';

export default function Login() {
    const Inputstyle={
        height:"50px"
    }
    const Buttonstyle={
        width:"100px",
        height:"50px",
    }
    return (
        <div className="container">
            <h1 className='text-center mt-5'>Sign up Now</h1>

            <div className='row justify-content-center'>
                <div className='col-lg-6 col-md-8 col-sm-10 col-12 bg-dark text-white p-4'>
                    <input type="text" className='form-control mb-3' style={Inputstyle} placeholder='UserName' />
                    <input type="text" className='form-control mb-3' style={Inputstyle} placeholder='Email' />
                    <input type="text" className='form-control mb-3' style={Inputstyle} placeholder='Password' />
                    <input type="submit" className='btn btn-dark btn-block' style={Buttonstyle} value="Sign Up" />
                </div>
            </div>
        </div>
    )
}
