import React, { useState } from 'react';

export default function Review() {
    const [state] = useState({
        user1: "https://images.unsplash.com/photo-1633332755192-727a05c4013d?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlcnxlbnwwfHwwfHx8MA%3D%3D",
        user2: "https://sources.roboflow.com/dzuGOec8v6bRLhxo590fQ69a22N2/cNc6Q78185vhZDZhqEdS/original.jpg",
        user3: "https://t3.ftcdn.net/jpg/02/43/12/34/360_F_243123463_zTooub557xEWABDLk0jJklDyLSGl2jrr.jpg",
        
    });

    const Imagestyle = {
        height: "200px",
        width: "200px"
    };

    return (
        <div className="container">
            <h1 className='text-center mt-5'>Reviews of Our Customers</h1>
            <div className='row justify-content-around'>
                {Object.entries(state).map(([key, value], index) => (
                    <div className='col-lg-4 col-md-6 col-sm-12 my-3' key={index}>
                        <div className='bg-dark text-white text-center p-3'>
                            <img src={value} style={Imagestyle} className="rounded-circle mb-3" alt={`User ${index + 1}`} />
                            <h1>Name: {`User ${index + 1}`}</h1>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Similique ex quaerat, nisi aut vitae dolorum! Autem impedit rerum sit corrupti facere, nulla expedita illum incidunt eligendi, aut perferendis est ipsum fugit, obcaecati ipsa a non animi nobis laboriosam officia! Obcaecati placeat dolore dolorem rem consectetur neque voluptatibus vitae odio dolorum!</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
