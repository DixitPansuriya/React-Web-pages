import React, { useState } from 'react';

export default function Mobiles() {
  const [state] = useState({
    iphone13: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/i/p/iphone-13-blue-thum1_1_2.jpg",
    iphone14: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/a/p/apple-iphone14-blue-thum1.jpg",
    iphone15: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/i/1/i1_2.jpg",
    iphone12: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/i/p/iphone-13-midnight-thum1_3.jpg",
    iphone11: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/a/p/apple-iphone14-starlight-thum1.jpg",
    iphone10: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/i/1/i13_1_1.jpg"
  });

  return (
    <div>
      <h1 className='mt-5 mx-5 text-center'>Mobiles</h1>

      <div className='row mx-1'>
        {Object.entries(state).map(([key, value], index) => (
          <div className='col-lg-4 col-md-6 col-sm-12 border text-center p-3' key={index}>
            <img src={value} alt="" style={{ maxWidth: '100%', height: 'auto' }} />
            <h1>{key.replace(/([a-z])([A-Z])/g, '$1 $2')}</h1>
            <p>$500</p>
            <button className='bg-dark text-white'>Buy Now</button>
          </div>
        ))}
      </div>
    </div>
  );
}
