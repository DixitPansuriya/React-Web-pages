import React, { useState } from 'react';

export default function Other() {
    const [state, setState] = useState({
        Homepod: 'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/homepod-mini-select-yellow-202110?wid=400&hei=400&fmt=jpeg&qlt=90&.v=1632925510000',
        AirpodsMax: 'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/airpods-max-select-pink-202011?wid=400&hei=400&fmt=jpeg&qlt=90&.v=1604022365000',
        magesafe: 'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MT253?wid=400&hei=400&fmt=jpeg&qlt=90&.v=1692994342983',
        airpods: 'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MME73?wid=400&hei=400&fmt=jpeg&qlt=90&.v=1632861342000'
    });

    return (
        <div>
            <h1 className='mt-5 mx-5'>Other Items</h1>

            <div className='row mx-1'>
                <div className='col-lg-3 col-md-6 col-sm-12 border text-center p-3'>
                    <div className="card h-100">
                        <img src={state.Homepod} alt="Apple HomePod" className="card-img-top" />
                        <div className="card-body">
                            <h1 className="card-title">Apple HomePod</h1>
                            <p className="card-text">$220</p>
                            <button className='btn btn-dark'>Buy Now</button>
                        </div>
                    </div>
                </div>

                <div className='col-lg-3 col-md-6 col-sm-12 border text-center p-3'>
                    <div className="card h-100">
                        <img src={state.AirpodsMax} alt="Apple HomePod" className="card-img-top" />
                        <div className="card-body">
                            <h1 className="card-title">Airpods Max</h1>
                            <p className="card-text">$20</p>
                            <button className='btn btn-dark'>Buy Now</button>
                        </div>
                    </div>
                </div>
                <div className='col-lg-3 col-md-6 col-sm-12 border text-center p-3'>
                    <div className="card h-100">
                        <img src={state.magesafe} alt="Apple HomePod" className="card-img-top" />
                        <div className="card-body">
                            <h1 className="card-title">Apple magesafe</h1>
                            <p className="card-text">$120</p>
                            <button className='btn btn-dark'>Buy Now</button>
                        </div>
                    </div>
                </div>
                <div className='col-lg-3 col-md-6 col-sm-12 border text-center p-3'>
                    <div className="card h-100">
                        <img src={state.airpods} alt="Apple HomePod" className="card-img-top" />
                        <div className="card-body">
                            <h1 className="card-title">Apple AIRPODS</h1>
                            <p className="card-text">$250</p>
                            <button className='btn btn-dark'>Buy Now</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}
