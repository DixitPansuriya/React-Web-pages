import React from 'react';

export default function Footer() {
    return (
        <footer className="bg-dark text-white py-5">
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <h2>I-mobile</h2>
                        <p>We Sells Best</p>
                        <div className="d-flex">
                            <div className="mr-4">
                                <h5>Products</h5>
                                <ul className="list-unstyled">
                                    <li><a href="#" className="text-white text-decoration-none">Iphones</a></li>
                                    <li><a href="#" className="text-white text-decoration-none">Speakers</a></li>
                                    <li><a href="#" className="text-white text-decoration-none">AirBuds</a></li>
                                </ul>
                            </div>
                            <div>
                                <h5>Services</h5>
                                <ul className="list-unstyled">
                                    <li><a href="#" className="text-white text-decoration-none">Support</a></li>
                                    <li><a href="#" className="text-white text-decoration-none">Feedback</a></li>
                                    <li><a href="#" className="text-white text-decoration-none">Online Shop</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6 d-flex justify-content-center align-items-center">
                        <i className="fab fa-facebook-f mx-2 fs-3"></i>
                        <i className="fab fa-twitter mx-2 fs-3"></i>
                        <i className="fab fa-google mx-2 fs-3"></i>
                        <i className="fab fa-dribbble mx-2 fs-3"></i>
                        <i className="fab fa-instagram mx-2 fs-3"></i>
                    </div>
                </div>
                <p className="text-center mt-4">@copyright All Rights Reserved</p>
            </div>
        </footer>
    );
}
