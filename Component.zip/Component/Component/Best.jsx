import React from 'react'

export default function Best() {
  return (
    <div>
      <h1 className='mt-5 bg-dark text-white text-center'>See Our Best Seller Mobiles</h1>
    </div>
  )
}
