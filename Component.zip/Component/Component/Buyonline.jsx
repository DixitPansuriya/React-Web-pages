import React, { useState } from 'react';

export default function Buyonline() {

    const [state,setstate]=useState({
safe:"https://s3no.cashify.in/estore/4f796cee0146414781024144a7c897a3.png?p=default&s=lg",
instant:"https://s3no.cashify.in/estore/3554c7e5a47448f7af7bbb967f8b95d9.png?p=default&s=lg",
deals:"https://s3no.cashify.in/estore/7a2c56b2eedd4a4ba2fcf309c96db7b2.png?p=default&s=lg"
    })
  return (
    <div>
      <h1 className='mt-5 mx-5'>Want To Buy Online</h1>

      <div className='row justify-content-around mx-1 '>
        <div className='col-lg-3 col-md-6 col-sm-12 bg-dark text-white text-center p-3'>
          <img src={state.safe} alt="" />
          <h1>Safe & Secure</h1>
          <p>Select your device & we’ll help you unlock the best selling price based on the present conditions of your gadget & the current market price.</p>
        </div>

        <div className='col-lg-3 col-md-6 col-sm-12 bg-dark text-white text-center p-3'>
          <img src={state.instant} alt="" />
          <h1>Instant Delivery</h1>
          <p>On accepting the price offered for your device, we’ll arrange a free pick up. and Giving best and instant Delivery.</p>
        </div>

        <div className='col-lg-3 col-md-6 col-sm-12 bg-dark text-white text-center p-3'>
          <img src={state.deals} alt="" />
          <h1>Best Price & Deals</h1>
          <p>Instant Cash will be handed over to you at time of pickup or through payment mode of your choice.</p>
        </div>
      </div>
    </div>
  );
}
