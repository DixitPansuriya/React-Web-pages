import React, { useState, useEffect } from 'react';

export default function Herosection() {
  const [imageStyle, setImageStyle] = useState({
    width: '100%',
    height: '600px'
  });

  useEffect(() => {
    function handleResize() {
      if (window.innerWidth <= 630) {
        setImageStyle({
          width: '100%',
          height: '400px'
        });
      } else {
        setImageStyle({
          width: '100%',
          height: '600px'
        });
      }
    }

    window.addEventListener('resize', handleResize);

    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []); 

  return (
    <div>
      <img
        src="https://www.apple.com/v/iphone-13/j/images/meta/iphone-13_specs__bpr60apdzuaa_og.png?202404050445"
        alt=""
        style={imageStyle}
      />
    </div>
  );
}
  